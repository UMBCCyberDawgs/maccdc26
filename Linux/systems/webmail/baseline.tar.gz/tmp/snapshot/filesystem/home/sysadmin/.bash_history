ls
cd ..
ls
cd sysadmin/
ls
cd ..
ls
cd admin/
ls
cd ~
ls
pwd
cat /etc/passwd
cat /etc/passwd
cat /etc/passwd
ls
cd ..
ls
ls -al
ls -al
ls -al
ls -al
ls
sudo userdel -r admin
sudo userdel -r user 
exit
ls
sudo userdel -r user
sudo userdel -r admin
cd ..
ls
cd ..
cd etc/
ls
exit
cat /etc/passwd
ls /home
sudo rm -rf /home/admin
sudo rm -rf /home/user
sudo userdel user
sudo userdel admin
cat /etc/passwd
sudo userdel user
sudo kill -9 1008
sudo userdel user
cat /etc/passwd
clear
sudo vim /etc/hostname
hostname
hostname webmail
sudo hostname webmail
hostname
hostnamectl set-hostname webmail
hostname
cat /etc/hostname
exit
hostnamectl 
vim /etc/hostname 
exit
ls
exit
ls
sudo a2enmod proxy_fcgi setenvif
exit
