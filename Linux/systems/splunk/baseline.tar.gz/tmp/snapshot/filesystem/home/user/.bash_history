ip a s
exit
usermod -aG wheel user
su root
sudo -l
visudo
su root
sudo -l
exit
sudo -l
ip a s
whoami
sudo -k
sudo -l
sudo cat /etc/passwd
cat /etc/os-release 
ls
exit
visudo
sudo visudo
whoami
ls
sudo -l
su root
sudo -l
exit
sudo -l
sudo -l
ls
cat /etc/group
ls
su root
sudo -l
ls
exit
sudo usermod -l sysadmin user
sudo -l
su root
sudo -l
exit
